from src.workflow import graph
from src.doc_manager import insert_documents
from langchain_core.messages import HumanMessage

def main():
    """
    Main loop for the DeepSeek RAG Chatbot.
    Continuously prompts the user for input and generates responses.
    """
    print("Welcome to the DeepSeek RAG Chat! Type 'quit' to exit.")
    
    # Initialize Pinecone with predefined documents
    insert_documents()

    # Chat loop
    while True:
        user_input = input("\nYou: ")
        if user_input.lower() in ['quit', 'exit', 'bye']:
            print("Goodbye!")
            break

       
        initial_state = {"messages": [HumanMessage(content=user_input)]}
        
        
        result = graph.invoke(initial_state)

        
        if "messages" in result:
            print("\nAssistant:", result["messages"][-1].content)

if __name__ == "__main__":
    main()
