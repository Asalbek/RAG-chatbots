from src.config import (
    DEEPSEEK_CHAT_INPUT_PRICE_PER_1M_CACHE_HIT,
    DEEPSEEK_CHAT_INPUT_PRICE_PER_1M_CACHE_MISS,
    DEEPSEEK_CHAT_OUTPUT_PRICE_PER_1M
)

# -------------------- API COST CALCULATOR --------------------
def deepseek_api_cost_calculator(completion_response):
    """
    Calculate and print the cost of using DeepSeek-Chat.
    """
    try:
        response_metadata = getattr(completion_response, "response_metadata", {})
        token_usage = response_metadata.get("token_usage", {})

        if not token_usage:
            print("Warning: No token usage data found!")
            return

        cache_hit = int(token_usage.get("prompt_cache_hit_tokens", 0))
        cache_miss = int(token_usage.get("prompt_cache_miss_tokens", 0))
        completion_tokens = int(token_usage.get("completion_tokens", 0))

        input_cost = ((cache_hit * DEEPSEEK_CHAT_INPUT_PRICE_PER_1M_CACHE_HIT) +
                      (cache_miss * DEEPSEEK_CHAT_INPUT_PRICE_PER_1M_CACHE_MISS)) / 1_000_000
        output_cost = (completion_tokens * DEEPSEEK_CHAT_OUTPUT_PRICE_PER_1M) / 1_000_000
        total_cost = input_cost + output_cost

        print(f"\n=== Cost Breakdown for DeepSeek-Chat ===")
        print(f"Cache Hit Tokens: {cache_hit} → ${cache_hit * DEEPSEEK_CHAT_INPUT_PRICE_PER_1M_CACHE_HIT / 1_000_000:.6f}")
        print(f"Cache Miss Tokens: {cache_miss} → ${cache_miss * DEEPSEEK_CHAT_INPUT_PRICE_PER_1M_CACHE_MISS / 1_000_000:.6f}")
        print(f"Output Tokens: {completion_tokens} → ${output_cost:.6f}")
        print(f"TOTAL COST: ${total_cost:.6f}")

    except Exception as e:
        print(f"Warning: Could not calculate costs - {str(e)}")
