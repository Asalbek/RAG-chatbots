from src.vector_store import index, embedding_model

# -------------------- INSERT DOCUMENTS INTO PINECONE --------------------
def insert_documents():
    """
    Insert predefined documents into Pinecone.
    """
    try:
        index.delete(delete_all=True)  # Clear existing data
        documents = [
            {"id": "1", "text": "Asalbek is a software engineer specializing in AI and ML."},
            {"id": "2", "text": "He has expertise in Deep Learning, NLP, and Retrieval-Augmented Generation (RAG)."},
            {"id": "3", "text": "Asalbek has worked on several AI projects integrating LangGraph and Pinecone."}
        ]

        vectors = []
        for doc in documents:
            vector = embedding_model.embed_query(doc["text"])
            metadata = {"text": doc["text"]}
            vectors.append((doc["id"], vector, metadata))

        index.upsert(vectors=vectors)
        print("Successfully inserted documents into Pinecone.")
    except Exception as e:
        print(f"Error inserting documents: {str(e)}")
