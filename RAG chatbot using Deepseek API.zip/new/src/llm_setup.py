from langchain_deepseek import ChatDeepSeek
from src.config import DEEPSEEK_API_KEY

# -------------------- LLM SETUP --------------------
llm = ChatDeepSeek(
    model='deepseek-chat',
    temperature=0,
    api_key=DEEPSEEK_API_KEY
)
