from langchain_core.tools import tool
from src.vector_store import vector_store

# -------------------- RETRIEVAL TOOL --------------------
@tool(response_format="content_and_artifact")
def retrieve(query: str):
    """
    Retrieve information related to a query from Pinecone.
    """
    retrieved_docs = vector_store.similarity_search(query, k=3)
    serialized = "\n\n".join(
        (f"Source: {doc.metadata}\nContent: {doc.page_content}")
        for doc in retrieved_docs
    )
    return serialized, retrieved_docs
