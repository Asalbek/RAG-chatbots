from pinecone import Pinecone as PineconeClient
from langchain_openai import OpenAIEmbeddings
from langchain.vectorstores import Pinecone
from src.config import OPENAI_API_KEY, PINECONE_API_KEY, PINECONE_ENVIRONMENT, INDEX_NAME

# -------------------- PINECONE INITIALIZATION --------------------
pc = PineconeClient(api_key=PINECONE_API_KEY, environment=PINECONE_ENVIRONMENT)
index = pc.Index(INDEX_NAME)

# Create a LangChain VectorStore Wrapper
embedding_model = OpenAIEmbeddings(api_key=OPENAI_API_KEY)
vector_store = Pinecone(index, embedding_model, "text")
